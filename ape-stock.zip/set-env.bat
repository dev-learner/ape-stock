@echo off
cd /d "%~dp0"

if not exist venv (
    echo Creating virtual environment...
    python -m venv venv
    if errorlevel 1 (
        echo Failed to create venv. Make sure Python is in PATH.
        pause
        exit /b 1
    )
)

call venv\Scripts\activate.bat

:menu
cls
echo.
echo Environment loaded. Ready.
echo.
echo Available scripts:
echo ------------------

setlocal enabledelayedexpansion
set n=0
for %%f in (scripts\*.py) do (
    set /a n+=1
    echo !n!. %%~nxf
    set "script!n!=%%f"
)

if !n! equ 0 (
    echo No scripts found.
    goto end
)

echo.
set /p choice=Enter number to run (or Ctrl+C to cancel): 

if "!choice!"=="" goto menu

set "selected=!script%choice%!"
if not defined selected (
    echo Invalid choice.
    pause
    goto menu
)

echo.
echo Running !selected! ...
echo.
python "!selected!"
echo.
pause
goto menu

:end
cmd /k